# Requirement

**Project code:** 10281
**Title:** Employee Performance Analysis
**Client:** INX Future Incorporated

## Business context

INX Future Incorporated is a data analytics and automation solutions provider
with fifteen years of global presence, consistently rated among the top twenty
employers for the past five years. Its human resource policies are widely
regarded as industry best practice.

Employee performance indexes have declined in recent years. Service delivery
escalations have increased and client satisfaction has fallen by eight
percentage points.

The Chief Executive Officer, Mr Brain, is aware of the issue but is reluctant to
penalise non-performing employees. His concern is that doing so would damage
morale across the whole workforce, potentially reducing performance further, and
would undermine the company's standing as an employer of choice — which is what
allows it to attract strong candidates in the first place.

He has therefore commissioned a data science project to identify the underlying
causes of the decline, so that any corrective action is grounded in evidence
rather than assumption.

## Requested insights

1. **Department-wise performance** — how performance varies across the six
   departments.
2. **Top three factors affecting employee performance** — the attributes most
   strongly associated with the performance rating.
3. **A trained predictive model** — capable of predicting employee performance
   from input factors, intended for use in hiring.
4. **Recommendations** — actions to improve employee performance, derived from
   the analysis.

## Data

`INX_Future_Inc_Employee_Performance_CDS_Project2_Data_V1_8.xls`

1,200 employee records across 28 columns: one identifier (`EmpNumber`),
twenty-six attributes, and the target variable `PerformanceRating`, which takes
values 2 (Low), 3 (Good) and 4 (Outstanding).

The file is stored unmodified at `data/raw/`. A data dictionary is provided at
`references/data_dictionary.md`.

## Deliverable constraints

Scripts are submitted as Jupyter notebooks with markdown commentary, following
the directory structure set out in the IABAC project submission guidelines
(`references/IABAC_CDS_Project_Submission_Guidelines_V1_2.pdf`).
