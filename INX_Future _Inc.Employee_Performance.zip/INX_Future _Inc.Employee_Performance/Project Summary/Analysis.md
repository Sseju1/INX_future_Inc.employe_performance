# Analysis

Interpretation of the data and the reasoning behind each methodological choice,
from data processing through to algorithm selection.

---

## 1. Data processing

### Condition of the raw data

The supplied file required no cleaning. Across 1,200 rows and 28 columns there
were no missing values, no duplicate records and no constant columns. No
imputation or row removal was performed.

### Columns excluded from modelling

`EmpNumber` is a unique employee identifier. It carries no information that
generalises to unseen employees, and leaving it in would allow a tree-based
model to memorise training rows.

`Attrition` was excluded for two reasons. It is realised after performance is
known, so it leaks future information. More decisively, the brief states the
model will be used in hiring, and attrition is unknowable for a candidate — a
model depending on it could not be deployed for its stated purpose. `Attrition`
is retained in the exploratory analysis, where it is treated as an outcome
rather than an input.

### Transformations

Seven text columns were label-encoded, and every fitted encoder was persisted so
the identical mapping can be replayed at prediction time. This matters because
`LabelEncoder` assigns codes in alphabetical order of the values it happens to
see; re-fitting on a different set of candidates would assign different codes to
the same job role and silently corrupt predictions.

Ordinal survey fields such as `EmpEnvironmentSatisfaction` and
`EmpWorkLifeBalance` already arrive as integers on a meaningful 1–4 scale and
were left as they are. `StandardScaler` was applied for the benefit of the
distance-based and linear algorithms in the comparison; the tree ensembles are
scale-invariant and unaffected by it.

No principal component analysis was performed. With only 25 predictors,
dimensionality is not a constraint, and the second business question asks
specifically which named factors drive performance — a question that components
formed from linear mixtures of the originals could not answer directly.

---

## 2. Correlation and feature interaction

`EmpEnvironmentSatisfaction` and `EmpLastSalaryHikePercent` show the strongest
association with the target. `YearsSinceLastPromotion` is negatively associated.

The four tenure variables — `ExperienceYearsAtThisCompany`,
`ExperienceYearsInCurrentRole`, `YearsWithCurrManager` and
`YearsSinceLastPromotion` — are strongly correlated with one another, since all
measure closely related aspects of time served. This multicollinearity would
destabilise the coefficients of a linear model and is one reason the linear
methods underperform here. Tree ensembles are unaffected by correlated inputs,
which informed the choice of final algorithm.

Correlation captures only monotonic linear structure, and several fields are
ordinal survey responses whose relationship with performance is stepped rather
than smooth. A weak correlation coefficient was therefore not treated as
grounds for excluding a feature; the model-based importances are the more
reliable guide.

---

## 3. Handling class imbalance

The target is heavily imbalanced: 874 Good against 194 Low and 132 Outstanding.
The majority class alone accounts for roughly 73 percent of the data, so a model
predicting Good for every employee would score 73 percent accuracy while being
useless for the business question. Accuracy was therefore always reported
alongside weighted F1, precision and recall.

SMOTE was applied to correct the balance, and the order of operations was chosen
deliberately:

1. **Stratified train-test split first**, so the rare Outstanding class stays
   proportionally represented in both halves.
2. **Scaler fitted on the training set only**, then applied to the test set.
   Fitting on the full data would let test-set statistics influence training.
3. **SMOTE applied to the training set only.** Oversampling before the split
   would place synthetic copies of training rows into the test set, producing an
   accuracy figure that cannot be reproduced on real data.

---

## 4. Cross-validation and leakage

The same trap that makes pre-split oversampling invalid also applies to
cross-validation, and it is subtler there.

SMOTE creates synthetic points by interpolating between neighbouring minority
samples. If cross-validation is run over data that was oversampled beforehand, a
synthetic row and the real rows it was derived from can be separated across the
training and validation folds. The model then effectively sees near-copies of
its validation data during training.

Both figures were computed to show the size of the effect:

| Procedure | Cross-validated accuracy |
|---|---|
| Cross-validation on pre-oversampled data | 96.18% (± 0.89) |
| Scaling and SMOTE re-fitted inside each fold | **92.71% (± 1.28)** |

The leaky procedure overstates accuracy by 3.48 percentage points. The lower
figure is quoted throughout this project as the expected performance on new
employees. The correct construction places scaling and SMOTE inside an
imbalanced-learn `Pipeline` so both are re-fitted within each fold.

---

## 5. Algorithm selection

Ten algorithms were compared under one identical preprocessing pipeline and
scored on the same held-out test set.

| Model | Accuracy (%) | Weighted F1 (%) |
|---|---|---|
| **Gradient Boosting** | **93.75** | **93.68** |
| Random Forest | 92.92 | 92.72 |
| XGBoost | 92.92 | 92.85 |
| Decision Tree | 89.17 | 89.39 |
| AdaBoost | 88.75 | 88.88 |
| Support Vector Machine | 82.08 | 82.17 |
| Neural Network | 80.83 | 80.77 |
| Naive Bayes | 77.50 | 78.43 |
| Logistic Regression | 75.00 | 76.38 |
| K-Nearest Neighbors | 55.83 | 59.71 |

The three tree ensembles lead, separated by under a percentage point — narrow
enough that the choice among them is not strongly determined by this table
alone.

The gap to the linear and distance-based methods is much wider. K-Nearest
Neighbours performs worst by a large margin, the expected outcome for a
distance-based method on 25 mixed-type features where label-encoded categories
create meaningless numeric distances. Logistic Regression is also weak,
consistent with the multicollinearity described in section 2.

Gradient Boosting was taken forward: it led on every metric, handles the
correlated tenure block without difficulty, and exposes feature importances
directly, which the second business question requires.

---

## 6. Hyperparameter tuning, and why the tuned model was rejected

A grid search was run over the leakage-free pipeline so the score guiding
selection would be honest. Eight combinations covered tree depth, learning rate
and ensemble size.

The search selected 200 estimators, learning rate 0.1 and maximum depth 5,
reaching 93.44 percent cross-validated accuracy against the default
configuration's 92.71 percent.

On the held-out test set, however:

| Configuration | Test accuracy (%) | Weighted F1 (%) |
|---|---|---|
| Gradient Boosting (defaults) | **93.75** | **93.68** |
| Gradient Boosting (tuned) | 92.50 | 92.32 |

The tuned model scores higher under cross-validation and lower on data it has
never seen. On 1,200 rows with an oversampled minority class, the deeper
ensemble fits the training folds more closely without generalising better. This
is precisely why a test set is held aside and used for no fitting or selection
decision.

**The default configuration was retained as the final model.** The tuning
attempt is reported rather than discarded — an analysis that shows the grid
search only when it happens to help is not reproducible.

---

## 7. Feature importance

Importances were read from the final model, the same object whose scores are
reported. Because Gini importance is biased towards high-cardinality features,
permutation importance was computed as an independent cross-check.

| Feature | Gini importance | Permutation importance |
|---|---|---|
| EmpEnvironmentSatisfaction | 35.32% | 0.2079 |
| EmpLastSalaryHikePercent | 29.47% | 0.1392 |
| YearsSinceLastPromotion | 16.39% | 0.0592 |
| EmpWorkLifeBalance | 7.05% | 0.0092 |
| EmpDepartment | 3.07% | 0.0425 |

Both methods place the same three features at the top in the same order, so the
ranking is not an artefact of the Gini measure. The top three account for 81.2
percent of total importance, with `EmpWorkLifeBalance` a distant fourth.

### A caveat on causation

The two leading factors are survey and compensation fields recorded at the same
time as the performance rating itself. Association is on much firmer ground here
than causation, and the salary hike relationship is genuinely ambiguous in
direction: a hike is normally awarded *because of* a prior good rating, which is
at least as plausible a reading as the hike having driven subsequent
performance. This qualification is carried into the recommendations, because a
policy of increasing hikes in the expectation of raising performance rests on
the weaker of the two interpretations.

---

## 8. Model limitations

The final model reaches 93.75 percent accuracy on the held-out test set, but the
per-class breakdown matters more than the headline:

| Class | Precision | Recall | Support |
|---|---|---|---|
| 2 – Low | 0.943 | 0.846 | 39 |
| 3 – Good | 0.944 | 0.971 | 175 |
| 4 – Outstanding | 0.880 | 0.846 | 26 |

Recall on both minority classes is materially weaker than on the majority class.
Roughly one in six genuinely Low employees and one in six genuinely Outstanding
employees are pulled towards a Good prediction.

This has a direct bearing on how the model may be used. The brief asks for a
clear indicator of non-performing employees. **This model does not provide one at
the individual level.** Errors on the Low class are frequent enough that using an
individual prediction to justify penalising a named employee would be unsafe,
and the CEO's stated concern about morale makes the cost of such an error
particularly high. The defensible use is aggregate — identifying which
departments and conditions are associated with weak performance.

Two further limits are worth recording. The Finance and Data Science
percentages rest on 49 and 20 employees respectively, so departmental rates for
those two are unstable. And for genuinely external hires, several features the
model leans on — recent salary hike, years since last promotion — describe an
employment history at INX that a candidate does not have; the model is on much
firmer ground for internal transfers and promotions.
