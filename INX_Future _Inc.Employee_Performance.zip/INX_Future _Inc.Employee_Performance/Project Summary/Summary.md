# Project Summary

**Project code:** 10281 — Employee Performance Analysis, INX Future Incorporated

---

## Summary of model and analysis

The dataset of 1,200 employee records required no cleaning: no missing values,
no duplicates, no constant columns. Two columns were removed before modelling —
`EmpNumber` as a pure identifier, and `Attrition` because it is realised after
performance is known and is unknowable for a job candidate, which would make a
model depending on it undeployable for its stated hiring purpose.

Seven categorical columns were label-encoded with the encoders persisted for
reuse at prediction time. The target is heavily imbalanced (874 Good, 194 Low,
132 Outstanding), so SMOTE was applied to the training set only, after a
stratified split and after fitting the scaler on training data alone.

Ten algorithms were compared under one identical pipeline. **Gradient Boosting**
was selected, reaching **93.75 percent accuracy and 93.68 percent weighted F1**
on a held-out test set that was used for no fitting or selection decision. Its
cross-validated accuracy, measured with scaling and SMOTE re-fitted inside each
fold, is **92.71 percent (± 1.28)**.

A grid search selected a deeper configuration that scored higher under
cross-validation but 1.25 points *lower* on the held-out test set. The default
configuration was retained, and the tuning attempt is reported rather than
discarded.

Techniques and tools: pandas, NumPy, scikit-learn, XGBoost, imbalanced-learn
(SMOTE and Pipeline), Matplotlib, Seaborn, joblib.

---

## Business question 1 — Department-wise performance

| Department | Employees | % Low | % Good | % Outstanding | Mean rating |
|---|---|---|---|---|---|
| Development | 361 | 3.6 | 84.2 | 12.2 | 3.09 |
| Data Science | 20 | 5.0 | 85.0 | 10.0 | 3.05 |
| Human Resources | 54 | 18.5 | 70.4 | 11.1 | 2.93 |
| Research & Development | 343 | 19.8 | 68.2 | 12.0 | 2.92 |
| Sales | 373 | 23.3 | 67.3 | 9.4 | 2.86 |
| Finance | 49 | 30.6 | 61.2 | 8.2 | 2.78 |

Development and Data Science are the strongest departments, both keeping low
performers under six percent of headcount.

Finance is the weakest, with 30.6 percent rated Low — nearly double the
company-wide rate of 16.2 percent. Sales follows at 23.3 percent, and Research
and Development at 19.8 percent.

**A caveat that should accompany this ranking:** Finance has only 49 employees
and Data Science only 20, against 373 in Sales and 361 in Development. The
percentages for the two small departments rest on few observations and would
move several points if a handful of employees changed rating. Sales — large,
weak and with the highest attrition — is the more reliable target on this
evidence.

---

## Business question 2 — Top three factors

| Rank | Factor | Importance |
|---|---|---|
| 1 | Employee Environment Satisfaction | 35.3% |
| 2 | Employee Last Salary Hike Percent | 29.5% |
| 3 | Years Since Last Promotion | 16.4% |
| | **Combined** | **81.2%** |

`EmpWorkLifeBalance` is a distant fourth at 7.1 percent. Both Gini and
permutation importance place the same three features at the top in the same
order, so the ranking is not an artefact of the measure used.

**On causation:** the first two factors are survey and compensation fields
recorded at the same time as the performance rating. The salary hike
relationship in particular is ambiguous in direction — a hike is normally
awarded *because of* a prior good rating, which is at least as plausible as the
hike having driven subsequent performance. The data cannot separate the two, and
the recommendations below are framed accordingly.

---

## Business question 3 — Trained predictive model

A Gradient Boosting classifier is saved at
`src/models/employee_performance_model.pkl`, bundled with its scaler, label
encoders and required column order so the full inference chain can be
reconstructed in a fresh session. Usage is demonstrated in
`src/models/predict_model.ipynb`.

| Metric | Value |
|---|---|
| Test accuracy | 93.75% |
| Weighted F1 | 93.68% |
| Cross-validated accuracy (leakage-free) | 92.71% (± 1.28) |

**The model's limitation must be stated alongside its accuracy.** Per-class
recall is 0.846 for Low, 0.971 for Good and 0.846 for Outstanding. Roughly one
in six genuinely Low employees is predicted as Good.

The brief asks for a clear indicator of non-performing employees. This model
does not provide one at the individual level. The error rate on the Low class is
high enough that using an individual prediction to justify penalising a named
employee would be unsafe — and given the CEO's stated concern that unfair
penalisation would damage morale across the workforce, the cost of such an error
is exactly the outcome the project was commissioned to avoid. The model's
defensible use is aggregate: identifying which departments and conditions are
associated with weak performance.

For hiring specifically, note that several features the model relies on describe
an employment history at INX. It is on firmer ground for internal transfers and
promotions than for external candidates.

---

## Business question 4 — Recommendations

**1. Treat environment satisfaction as the primary lever.** It is the strongest
predictor by a clear margin, and unlike compensation it is not confounded by
being an outcome of past ratings. Run engagement diagnostics in Finance, Sales
and Research and Development to identify what specifically is driving low
scores, then address those causes. This is the highest-confidence
recommendation in this report.

**2. Prioritise Sales for combined intervention.** Sales is the only department
where a retention problem and a performance problem coincide: 18.8 percent
attrition alongside 23.3 percent low performers, across 373 employees. It offers
the largest addressable population and the clearest business case.

**3. Investigate Finance as a structural problem, not a retention one.** Finance
has the worst performance in the company (30.6 percent Low) but the *lowest*
attrition (6.1 percent). Underperforming staff are staying rather than leaving,
which points towards role design, workload or management rather than turnover,
and calls for a different remedy than Sales needs. Given the small headcount,
begin with qualitative review rather than a programme built on the percentage.

**4. Review promotion cadence.** Longer gaps since last promotion are associated
with lower ratings. Clearer career frameworks and more frequent role-growth
reviews are a reasonable response, targeted at employees with the longest stalls.

**5. Audit salary hike distribution — but pilot before scaling.** Hike
percentage is strongly associated with performance, but because hikes are
typically awarded on the basis of prior ratings, the causal direction is
unresolved. Treat this as a hypothesis to test on a limited population rather
than a company-wide policy change, and measure the outcome before committing.

**6. Do not act on the overtime figures.** The data shows employees working
overtime are rated Low *less* often than those who do not (11.0 percent against
18.3 percent) — the opposite of the intuitive expectation. The most likely
explanation is selection, in that engaged employees take on extra hours, but the
data does not establish this. It supports no policy change in either direction.

**7. Use the model as a screening aid with human judgement, and retrain
periodically.** It should inform decisions, never make them, and it should not
be used to justify action against an individual employee.

---

## Additional insights

Attrition and performance do not move together across the company. Sales has
both problems; Finance has weak performance with unusually loyal staff;
Development has moderate attrition (14.1 percent) alongside the best performance
in the company. A single company-wide retention programme would therefore be the
wrong instrument — the departments need different remedies.

The four tenure variables are strongly correlated with one another, which
explains why the linear models in the comparison performed poorly and why tree
ensembles were the appropriate choice.

Beyond the top three factors, `EmpWorkLifeBalance` (7.1 percent), department
(3.1 percent) and job role (1.8 percent) carry modest weight. No other single
feature exceeds two and a half percent, so interventions targeting the leading
three factors address the substantial majority of what the model can explain.
